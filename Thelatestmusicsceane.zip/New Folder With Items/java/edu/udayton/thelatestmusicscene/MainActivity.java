package edu.udayton.thelatestmusicscene;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.ListMenuItemView;

import android.content.Intent;
import android.net.sip.SipSession;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnstorytwo = (Button)findViewById(R.id.second);

        View.OnClickListener btnstorytwoListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent storytwo = new Intent(MainActivity.this, storytwo.class);

                startActivity(storytwo);
            }
        };
        btnstorytwo.setOnClickListener(btnstorytwoListener);


        Button btnstoryone = (Button)findViewById(R.id.buttonone);

        View.OnClickListener btnstoryoneListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent storyone = new Intent(MainActivity.this, storyone.class);

                startActivity(storyone);


            }
        };

        btnstoryone.setOnClickListener(btnstoryoneListener);


    }
}